document.addEventListener("DOMContentLoaded", function()
{
	let form = document.querySelectorAll(".edit_link");
	if(form.length > 0)
	{
		form[0].submit();
	}
});
