document.addEventListener("DOMContentLoaded", function()
{
	let btn = document.getElementById("btd");
	if(btn != null)
	{
		btn.click();
	}
});
