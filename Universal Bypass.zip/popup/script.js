window.open("https://universal-bypass.org/");
window.close();
