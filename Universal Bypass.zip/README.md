# Universal Bypass

Don't waste your time with compliance. Universal Bypass automatically skips annoying link shorteners.

- [Get the Extension for Chrome & Firefox](https://universal-bypass.org)
